package com.example.springBankApp.services;

import com.example.springBankApp.exceptions.AccountNotFound;
import com.example.springBankApp.models.AccountInfo;
import com.example.springBankApp.repositories.AccountRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

// Service class for the account services
@Service
@Transactional
public class AccountService {

//    Instance of the account repository
    @Autowired
    private AccountRepo accountRepo;

//    add an account
    public String addAccount(AccountInfo accountInfo) {
         this.accountRepo.save(accountInfo);
         return "Account successfully created";
    }

//    get the account details by the account no
    public AccountInfo getAccount(int accNo) throws AccountNotFound {
        Optional<AccountInfo> accountInfo = this.accountRepo.findById(accNo);
        if (accountInfo.isPresent()) {
            return accountInfo.get();
        } else {
            throw new AccountNotFound();
        }
    }

//    update the account details
    public String updateAccount(AccountInfo accountInfo) throws AccountNotFound {
        if (this.accountRepo.existsById(accountInfo.getAccNo())) {
            this.accountRepo.save(accountInfo);
            return "Account is updated";
        }
        throw new AccountNotFound();
    }

//    deletes the account
    public String deleteAccount(int accNo) throws AccountNotFound {
        if (this.accountRepo.existsById(accNo)) {
            this.accountRepo.deleteById(accNo);
            return "Account is updated";
        }
        throw new AccountNotFound();
    }
}
