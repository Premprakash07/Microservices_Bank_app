package com.example.springBankApp.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

import java.time.LocalDateTime;

// Transaction infomation class
@Entity
@Table
public class TransactionInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int transId;

    private double amount;

    @Temporal(TemporalType.TIMESTAMP)
    private LocalDateTime transactionTime = LocalDateTime.now();

    @NotBlank(message = "Please provide transfer type")
    private String transactionType;

    @NotBlank(message = "Please provide payers account no. ")
    private int fromAcc;

    @NotBlank(message = "Please provide payers account no. ")
    private int toAcc;

    public TransactionInfo() {}

    public TransactionInfo(double amount, String transactionType, int fromAcc, int toAcc) {
        this.amount = amount;
        this.transactionType = transactionType;
        this.fromAcc = fromAcc;
        this.toAcc = toAcc;
    }

    public int getTransId() {
        return transId;
    }

    public void setTransId(int transId) {
        this.transId = transId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDateTime getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(LocalDateTime transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public int getFromAcc() {
        return fromAcc;
    }

    public void setFromAcc(int fromAcc) {
        this.fromAcc = fromAcc;
    }

    public int getToAcc() {
        return toAcc;
    }

    public void setToAcc(int toAcc) {
        this.toAcc = toAcc;
    }
}
