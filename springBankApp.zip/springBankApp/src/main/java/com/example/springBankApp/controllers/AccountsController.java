package com.example.springBankApp.controllers;

import com.example.springBankApp.exceptions.AccountNotFound;
import com.example.springBankApp.models.AccountInfo;
import com.example.springBankApp.services.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

// Controller for the accounts
@RestController
@RequestMapping("/account")
public class AccountsController {

    @Autowired
    private AccountService accountService;

    @PostMapping("/add")
    public String addAccount(@RequestBody AccountInfo accountInfo) {
        return this.accountService.addAccount(accountInfo);
    }

    @GetMapping("/get/{accNo}")
    public AccountInfo getAccount(@PathVariable("accNo") int accNo) throws AccountNotFound {
        return this.accountService.getAccount(accNo);
    }

    @PutMapping("/update")
    public String updateAccount(@RequestBody AccountInfo accountInfo) throws AccountNotFound {
        return this.accountService.updateAccount(accountInfo);
    }

    @DeleteMapping("/delete/accNo")
    public String deleteAccount(@PathVariable("accNo") int accNo) throws AccountNotFound {
        return this.accountService.deleteAccount(accNo);
    }
}
