package com.example.springBankApp.exceptions;

// Account not found exception
public class AccountNotFound extends Exception{
    public AccountNotFound() {
        super("Account not found");
    }
}
