package com.example.springBankApp.repositories;

import com.example.springBankApp.models.AccountInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// Account repository class
@Repository
public interface AccountRepo extends JpaRepository<AccountInfo, Integer> {

}
