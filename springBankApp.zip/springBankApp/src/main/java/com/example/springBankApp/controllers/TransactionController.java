package com.example.springBankApp.controllers;

import com.example.springBankApp.exceptions.AccountNotFound;
import com.example.springBankApp.models.TransactionInfo;
import com.example.springBankApp.services.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Controller for the transaction
@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/withdraw/{accNo}/{amount}")
    public String withdraw(@PathVariable("accNo") int accNo, @PathVariable("amount") double amount) throws Exception {
        return this.transactionService.withdraw(accNo, amount);
    }

    @PostMapping("/deposit/{accNo}/{amount}")
    public String deposit(@PathVariable("accNo") int accNo, @PathVariable("amount") double amount) throws Exception {
        return this.transactionService.deposit(accNo, amount);
    }

    @PostMapping("/transfer/{type}/{fromAcc}/{toAcc}/{amount}")
    public String transfer(@PathVariable("type") String type, @PathVariable("toAcc") int toAcc, @PathVariable("fromAcc") int fromAcc, @PathVariable("amount") double amount) throws Exception {
        return this.transactionService.transfer(type, amount, fromAcc, toAcc);
    }

    @GetMapping("/getallbyacc/{accNo}")
    public List<TransactionInfo> getallByAccNo(@PathVariable("accNo") int accNo) throws AccountNotFound {
        return this.transactionService.getAllTransactionByAccNo(accNo);
    }
}
