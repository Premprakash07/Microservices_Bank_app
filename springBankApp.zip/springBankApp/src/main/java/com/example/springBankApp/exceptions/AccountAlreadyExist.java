package com.example.springBankApp.exceptions;

// Account already exist exception
public class AccountAlreadyExist extends Exception{
    public AccountAlreadyExist() {
        super("Account already exists");
    }
}
