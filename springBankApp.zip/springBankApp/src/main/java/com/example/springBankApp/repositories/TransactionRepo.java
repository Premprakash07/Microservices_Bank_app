package com.example.springBankApp.repositories;

import com.example.springBankApp.models.TransactionInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

// Transaction repository class
@Repository
public interface TransactionRepo extends JpaRepository<TransactionInfo, Integer> {

//    Query to get the transaction by account no
    @Query("select t from TransactionInfo t where t.fromAcc = ?1 or t.toAcc = ?1")
    List<TransactionInfo> findAllByAccNo(int accNo);
}
